# Dracula for [iTerm 2](http://iterm2.com)

> A dark theme for [iTerm 2](http://iterm2.com).

![Screenshot](https://draculatheme.com/assets/img/screenshots/iterm.png)

## Install

All instructions can be found at [draculatheme.com/iterm](https://draculatheme.com/iterm).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/iterm/graphs/contributors).

[![Harrison Heck](https://avatars0.githubusercontent.com/u/1037526?v=3&s=70)](https://github.com/nesl247) |
--- |
[Harrison Heck](https://github.com/nesl247) |

## License

[MIT License](./LICENSE)
