# Dracula for [Sublime Text](http://sublimetext.com)

> A dark theme for [Sublime Text](http://sublimetext.com).

![Screenshot](https://draculatheme.com/assets/img/screenshots/sublime.png)

## Install

All instructions can be found at [draculatheme.com/sublime](https://draculatheme.com/sublime).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/atom/graphs/contributors).

[![Zeno Rocha](https://avatars2.githubusercontent.com/u/398893?v=3&s=70)](https://github.com/zenorocha) |
--- |
[Zeno Rocha](https://github.com/zenorocha) |

## License

[MIT License](./LICENSE)
