# Dracula for [Terminal.app](https://en.wikipedia.org/wiki/Terminal_(macOS))

> A dark theme for [Terminal.app](https://en.wikipedia.org/wiki/Terminal_(macOS)).

![Screenshot](https://draculatheme.com/assets/img/screenshots/terminal.png)

## Install

All instructions can be found at [draculatheme.com/terminal](https://draculatheme.com/terminal).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/terminal.app/graphs/contributors).

[![Harrison Heck](https://avatars0.githubusercontent.com/u/1037526?v=3&s=70)](https://github.com/nesl247) |
--- |
[Harrison Heck](https://github.com/nesl247) |

## License

[MIT License](./LICENSE)
