# Dracula for [ZSH](http://zsh.org)

> A dark theme for [ZSH](http://zsh.org).

![Screenshot](https://draculatheme.com/assets/img/screenshots/zsh.png)

## Install

All instructions can be found at [draculatheme.com/zsh](https://draculatheme.com/zsh).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/zsh/graphs/contributors).

[![Harrison Heck](https://avatars0.githubusercontent.com/u/1037526?v=3&s=70)](https://github.com/nesl247) |
--- | ---
[Harrison Heck](https://github.com/nesl247) |

## License

[MIT License](./LICENSE)
