# Setup fzf
# ---------
if [[ ! "$PATH" == */Users/irfan-devops/Desktop/fzf/bin* ]]; then
  export PATH="$PATH:/Users/irfan-devops/Desktop/fzf/bin"
fi

# Auto-completion
# ---------------
[[ $- == *i* ]] && source "/Users/irfan-devops/Desktop/fzf/shell/completion.zsh" 2> /dev/null

# Key bindings
# ------------
source "/Users/irfan-devops/Desktop/fzf/shell/key-bindings.zsh"

